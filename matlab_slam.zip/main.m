clear; close all; clc;

%cfig = figure('Position', [10,10,1280,1080]);
cfig = figure(1);


% Lidar parameters
lidar = SetLidarParameters();

% Map parameters
borderSize      = 1;            % m
pixelSize       = 0.2;          % m 0.2
ifMove     = false;        % 
ifMoveT    = 0.1;          % m
ifMoveR    = deg2rad(5);   % rad
% If the robot has moved 0.1 m or rotated 5 degree from last key scan, 
% we would add a new key scan and update the map
% Scan matching parameters
fastResolution  = [0.02; 0.02; deg2rad(0.4)]; % [m; m; rad]0.05 0.05 0.0087
bruteResolution = [0.01; 0.01; deg2rad(0.1)]; % not used


% Load lidar data
lidar_data = load('dataset/2d_lidar.mat');% change times -> timestamps if needed

N = size(lidar_data.times, 1);
%disp(['size of database_mat = ',num2str(N)]);

% Create an empty map
map.points = [];
map.connections = [];
map.keyscans = [];
pose = [0; 0; 0];
path = pose;

%是否将绘制过程保存成视频
saveFrame=0;
if saveFrame==1
    % 视频保存文件定义与打开
    writerObj=VideoWriter('SLAMprocess.avi');  % 定义一个视频文件用来存动画
    open(writerObj);                    % 打开该视频文件
end
tic
% Here we go!!!!!!!!!!!!!!!!!!!!
    time = lidar_data.times(1) * 1e-9;
    %disp(['times = ',num2str(lidar_data.times(1))]);
for Scan_Data_n = 1 : 1 : N
    
    disp(['scan ', num2str(Scan_Data_n)]);
    
    % Get current scan [x1,y1; x2,y2; ...]

    scan = ReadAScan(lidar_data, Scan_Data_n, lidar, 24);
    %24 is the usable range optional
    % output [xs,ys]-> cartesian cordinates
    
    % If it's the first scan, initiate
    if Scan_Data_n == 1
        map = Initialize(map, pose, scan);
        ifMove = true;
        pose_guess = pose;%Scan_Data_n=2/1
        continue;
    end
    if Scan_Data_n >2
        pose_guess = pose + DiffPose(path(:,end-1), pose);
    end
%     if Scan_Data_n > 2
%         
%         pose_guess = pose + DiffPose(path(:,end-1), pose);
%     else
%         pose_guess = pose;%Scan_Data_n=2/1
%     end
    % ===== Matching current scan to local map ============
    % 1. If we executed a mini update in last step, we shall update the
    %    local points map and local grid map (coarse)
    if ifMove
        localMap = ExtractLocalMap(map.points, pose, scan, borderSize);
        gridMap1 = OccuGrid(localMap, pixelSize);%pixelsize is defined at first 0.2 here
        gridMap2 = OccuGrid(localMap, pixelSize/2);
    end
    
    % 2. Predict current pose using constant velocity motion model
   
        
    % 3. Fast matching
    if ifMove
        [pose, ~] = FastMatch(gridMap1, scan, pose_guess, fastResolution);
        %[pose, ~] = FastMatch(gridMap1, scan, pose_guess, bruteResolution);
    else
        [pose, ~] = FastMatch(gridMap2, scan, pose_guess, fastResolution);
        %[pose, ~] = FastMatch(gridMap2, scan, pose_guess, bruteResolution);
    end
    
    % 4. Refine the pose using smaller pixels
    % gridMap = OccuGrid(localMap, pixelSize/2);
    [pose, hits] = FastMatch(gridMap2, scan, pose, fastResolution/2);
    %[pose, hits] = FastMatch(gridMap2, scan, pose, bruteResolution/2);
    %----------------------------------------------------------------------
    
    
    % Execute a mini update, if the robot has moved a certain distance
    dp = abs(DiffPose(map.keyscans(end).pose, pose));
    if dp(1)>ifMoveT || dp(2)>ifMoveT || dp(3)>ifMoveR
        ifMove = true;
        [map, pose] = AddAKeyScan(map, gridMap2, scan, pose, hits,...
                        pixelSize, bruteResolution, 0.1, deg2rad(3));
    else
        ifMove = false;
    end    
    path = [path, pose];      
    
    
    % ===== Loop Closing =========================================
    if ifMove
        if TryLoopOrNot(map)
            map.keyscans(end).loopTried = true;
            map = DetectLoopClosure(map, scan, hits, 4, pi/6, pixelSize);
        end
    end
    
    %----------------------------------------------------------------------
    
    % Plot
    if mod(Scan_Data_n, 60) == 0
        PlotMap(cfig, map, path, scan, Scan_Data_n);
        if saveFrame==1
            frame = getframe(cfig);
            writeVideo(writerObj, frame);
        end
    end
end

if saveFrame==1
    close(writerObj);
end
toc
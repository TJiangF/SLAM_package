#include <iostream>
#include <pcl/io/pcd_io.h> 
#include <pcl/point_types.h>
#include <pcl/kdtree/kdtree_flann.h>

using namespace std;

#pragma region //������Ƶĵ��Ǿ���
double computeChamferDistance(pcl::PointCloud<pcl::PointXYZ>::ConstPtr cloud_a, pcl::PointCloud<pcl::PointXYZ>::ConstPtr cloud_b)
{

    // cloud_a��ÿһ������cloud_b�в���������ڵ�
    pcl::KdTreeFLANN<pcl::PointXYZ> kdtree_b;
    kdtree_b.setInputCloud(cloud_b);
    double sum_a = 0.0;
    std::vector<int> pointIdxKNNSearch(1);
    std::vector<float> pointKNNSquaredDistance(1);

    for (auto point_iter_a = (*cloud_a).begin(); point_iter_a != (*cloud_a).end(); ++point_iter_a)
    {

        pcl::PointXYZ point_a = *point_iter_a;
        if (kdtree_b.nearestKSearch(point_a, 1, pointIdxKNNSearch, pointKNNSquaredDistance) > 0)
        {

            sum_a += pointKNNSquaredDistance[0];
        }
    }

    // cloud_b��ÿһ������cloud_a�в���������ڵ�
    pcl::KdTreeFLANN<pcl::PointXYZ> kdtree_a;
    kdtree_a.setInputCloud(cloud_a);
    double sum_b = 0.0;
    // ���vector����
    pointIdxKNNSearch.clear();
    pointKNNSquaredDistance.clear();

    for (auto point_iter_b = (*cloud_b).begin(); point_iter_b != (*cloud_b).end(); ++point_iter_b)
    {

        pcl::PointXYZ point_b = *point_iter_b;
        if (kdtree_a.nearestKSearch(point_b, 1, pointIdxKNNSearch, pointKNNSquaredDistance) > 0)
        {

            sum_b += pointKNNSquaredDistance[0];
        }
    }

    return (1.0 / (*cloud_a).size()) * sum_a + (1.0 / (*cloud_b).size()) * sum_b;// ���㵹�Ǿ���
}
#pragma endregion

int main(int argc, char** argv)
{

    pcl::PointCloud<pcl::PointXYZ>::Ptr cloudA(new pcl::PointCloud<pcl::PointXYZ>);
    pcl::io::loadPCDFile<pcl::PointXYZ>("lab_carto_org_ali.pcd", *cloudA);

    pcl::PointCloud<pcl::PointXYZ>::Ptr cloudB(new pcl::PointCloud<pcl::PointXYZ>);
    pcl::io::loadPCDFile<pcl::PointXYZ>("lab_ref_carto.pcd", *cloudB);

    double chamfer_distance = computeChamferDistance(cloudA, cloudB);

    std::cout << "���Ǿ���Ϊ:" << chamfer_distance<< std::endl;

    return 0;
}